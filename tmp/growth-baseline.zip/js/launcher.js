(function () {
  const services = document.getElementById('servicesSheet');
  const settings = document.getElementById('settingsPanel');
  const form = document.getElementById('preferenceForm');
  const openServices = document.getElementById('openServices');
  const openSettings = document.getElementById('openSettings');
  const desktopDownload = document.getElementById('downloadDesktopInstaller');
  const biometricInput = form.elements.biometric;
  const biometricHint = document.getElementById('biometricPreferenceHint');
  let lastTrigger = null;

  function focusable(panel) {
    return [...panel.querySelectorAll('a[href], button:not([disabled]), input:not([disabled])')];
  }

  function openPanel(panel, trigger) {
    [services, settings].forEach((item) => { if (item !== panel) item.hidden = true; });
    lastTrigger = trigger;
    panel.hidden = false;
    document.body.classList.add('launcher-modal-open');
    requestAnimationFrame(() => panel.classList.add('is-open'));
    focusable(panel)[0]?.focus();
  }

  function closePanel(panel) {
    panel.classList.remove('is-open');
    panel.hidden = true;
    document.body.classList.remove('launcher-modal-open');
    lastTrigger?.focus();
  }

  function populateForm() {
    const preferences = window.DIGCPreferences.read();
    form.elements.theme.value = preferences.theme;
    form.elements.accent.value = preferences.accent;
    form.elements.largeText.checked = preferences.largeText;
    form.elements.compact.checked = preferences.compact;
    form.elements.reduceMotion.checked = preferences.reduceMotion;
    biometricInput.checked = preferences.biometric;
  }

  openServices.addEventListener('click', () => openPanel(services, openServices));
  openSettings.addEventListener('click', () => {
    populateForm();
    openPanel(settings, openSettings);
  });

  document.querySelectorAll('[data-close-panel]').forEach((button) => {
    button.addEventListener('click', () => closePanel(button.closest('.launcher-overlay')));
  });

  [services, settings].forEach((panel) => {
    panel.addEventListener('click', (event) => {
      if (event.target === panel) closePanel(panel);
    });
    panel.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') closePanel(panel);
      if (event.key !== 'Tab') return;
      const items = focusable(panel);
      const first = items[0];
      const last = items[items.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    });
  });

  form.addEventListener('change', () => {
    window.DIGCPreferences.apply({
      theme: form.elements.theme.value,
      accent: form.elements.accent.value,
      largeText: form.elements.largeText.checked,
      compact: form.elements.compact.checked,
      reduceMotion: form.elements.reduceMotion.checked,
      biometric: biometricInput.checked
    });
  });

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    window.DIGCPreferences.save({
      theme: form.elements.theme.value,
      accent: form.elements.accent.value,
      largeText: form.elements.largeText.checked,
      compact: form.elements.compact.checked,
      reduceMotion: form.elements.reduceMotion.checked,
      biometric: biometricInput.checked
    });
    closePanel(settings);
  });

  document.getElementById('resetPreferences').addEventListener('click', () => {
    window.DIGCPreferences.save(window.DIGCPreferences.defaults);
    populateForm();
  });

  desktopDownload?.addEventListener('click', async (event) => {
    event.preventDefault();
    if (desktopDownload.dataset.loading === '1') return;

    const fallbackUrl = desktopDownload.href;
    const originalLabel = desktopDownload.textContent;
    desktopDownload.dataset.loading = '1';
    desktopDownload.setAttribute('aria-busy', 'true');
    desktopDownload.textContent = 'Preparing download...';

    let installerUrl = fallbackUrl;
    try {
      const response = await fetch('version.json', { cache: 'no-store' });
      if (!response.ok) throw new Error('The desktop release manifest is unavailable.');
      const release = await response.json();
      const candidate = new URL(String(release?.installer_url || ''), window.location.href);
      if (candidate.protocol !== 'https:') throw new Error('The installer URL must use HTTPS.');
      installerUrl = candidate.href;
    } catch (error) {
      console.warn('Using the stable Dynamax Desktop download fallback.', error);
    } finally {
      desktopDownload.dataset.loading = '0';
      desktopDownload.removeAttribute('aria-busy');
      desktopDownload.textContent = originalLabel;
    }

    window.location.assign(installerUrl);
  });

  (async function checkBiometricSupport() {
    let supported = Boolean(window.PublicKeyCredential && navigator.credentials);
    if (supported && PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable) {
      supported = await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable().catch(() => false);
    }
    biometricInput.disabled = !supported;
    biometricInput.closest('.preference-switch-row').classList.toggle('is-unavailable', !supported);
    if (!supported) {
      biometricInput.checked = false;
      biometricHint.textContent = 'This browser or device does not offer secure biometric sign-in';
    }
  }());
})();
