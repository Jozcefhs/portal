const otpRequestForm = document.getElementById('otpRequestForm');
const lookupForm = document.getElementById('paymentLookupForm');
const statusEl = document.getElementById('paymentStatus');
const sendOtpBtn = document.getElementById('sendOtpBtn');
const lookupBtn = document.getElementById('lookupBtn');
const restartOtpBtn = document.getElementById('restartOtpBtn');
const otpDeliverySummary = document.getElementById('otpDeliverySummary');
const feePanel = document.getElementById('feePanel');
const feeList = document.getElementById('feeList');
const accountSummary = document.getElementById('accountSummary');
const payBtn = document.getElementById('payBtn');
const breakdownEl = document.getElementById('schoolFeeBreakdown');
const walletAmountBox = document.getElementById('walletAmountBox');
const walletAmountInput = document.getElementById('walletAmount');

let currentAdmissionNumber = '';
let guestPaymentChallengeId = '';
let guestPaymentToken = '';
let currentFees = [];
let currentBreakdown = [];
let currentBranchId = 'main';
let paymentIdempotencyKey = '';
const debugMode = new URLSearchParams(window.location.search).get('debug') === '1';

const SCHOOL_FEES_TOTAL_CODE = 'SCHOOL_FEES_TOTAL';

function newIdempotencyKey() {
  if (window.crypto?.randomUUID) return window.crypto.randomUUID();
  const random = window.crypto?.getRandomValues
    ? Array.from(window.crypto.getRandomValues(new Uint32Array(4)), (value) => value.toString(16)).join('')
    : Math.random().toString(36).slice(2);
  return `${Date.now().toString(36)}-${random}`;
}

function shouldReleaseIdempotencyKey(response, data) {
  const status = Number(response?.status || 0);
  if (response?.ok && data?.ok) return true;
  if (status < 400 || status >= 500 || [408, 425, 429].includes(status)) return false;
  if (status === 409 && /IDEMPOTENCY_(IN_PROGRESS|LOCKED|OWNERSHIP_LOST|OUTCOME_UNCERTAIN)|already being processed|outcome.+uncertain|unresolved request|no longer owned/i.test(
    `${data?.code || ''} ${data?.message || ''}`
  )) return false;
  return status < 500;
}

function setStatus(message, type) {
  statusEl.textContent = message || '';
  statusEl.className = 'status ' + (type || '');
}

function clearGuestPaymentAuthorization() {
  guestPaymentChallengeId = '';
  guestPaymentToken = '';
  paymentIdempotencyKey = '';
  feePanel.hidden = true;
}

async function publicTurnstile(action) {
  return window.DynamaxPublicApi?.getTurnstileToken
    ? window.DynamaxPublicApi.getTurnstileToken(action)
    : {};
}

function formatMoney(amount, currency) {
  const number = Number(String(amount || '0').replace(/,/g, ''));
  return new Intl.NumberFormat('en-NG', {
    style: 'currency',
    currency: currency || 'NGN'
  }).format(Number.isFinite(number) ? number : 0);
}

function isWalletFee(fee) {
  return fee && (fee.FeeCode === 'WALLET_TOPUP' || String(fee.FeeCategory || '').toLowerCase() === 'wallet');
}

function isSchoolFee(fee) {
  return fee && !isWalletFee(fee) && String(fee.FeeCategory || 'School Fee').trim().toLowerCase() === 'school fee';
}

function isSchoolFeesTotal(fee) {
  return fee && String(fee.FeeCode || '') === SCHOOL_FEES_TOTAL_CODE;
}

function toAmount(value) {
  const amount = Number(String(value || '0').replace(/,/g, ''));
  return Number.isFinite(amount) ? amount : 0;
}

function isYes(value) {
  return ['yes', 'y', 'true', '1'].includes(String(value || '').trim().toLowerCase());
}

function termText(feeOrAccount) {
  const term = String((feeOrAccount && feeOrAccount.Term) || '').trim();
  const session = String((feeOrAccount && feeOrAccount.AcademicSession) || '').trim();
  const parts = [];
  if (term && term.toLowerCase() !== 'all') parts.push(term);
  if (session && session.toLowerCase() !== 'all') parts.push(session);
  return parts.join(' | ');
}

function selectedFee() {
  const selected = document.querySelector('input[name="feeCode"]:checked');
  if (!selected) return null;
  return currentFees.find((fee) => String(fee.FeeCode) === selected.value) || null;
}

function paymentAmountRules(fee) {
  if (!fee) return { show: false, min: 0, max: 0, defaultAmount: '' };
  if (isWalletFee(fee)) {
    return {
      show: true,
      label: 'Wallet Top-up Amount',
      min: toAmount(fee.MinAmount),
      max: toAmount(fee.MaxAmount),
      defaultAmount: fee.MinAmount || ''
    };
  }
  if (isSchoolFeesTotal(fee) && isYes(fee.AllowInstallment)) {
    const fullAmount = toAmount(fee.Amount);
    const minAmount = toAmount(fee.MinAmount);
    return {
      show: true,
      label: 'School Fee Amount to Pay Now',
      min: minAmount,
      max: fullAmount,
      defaultAmount: minAmount > 0 ? minAmount : fullAmount
    };
  }
  return { show: false, min: 0, max: 0, defaultAmount: '' };
}

function updateWalletAmountVisibility() {
  const fee = selectedFee();
  const rules = paymentAmountRules(fee);
  const label = walletAmountBox.querySelector('label');
  walletAmountBox.hidden = !rules.show;
  if (label) label.textContent = rules.label || 'Amount';
  walletAmountInput.min = rules.min > 0 ? String(rules.min) : '0';
  walletAmountInput.max = rules.max > 0 ? String(rules.max) : '';
  if (rules.show && !walletAmountInput.value) {
    window.DynamaxFinancialValues?.set(walletAmountInput, rules.defaultAmount || '');
  }
  if (!rules.show) {
    window.DynamaxFinancialValues?.set(walletAmountInput, '');
  }
}

function renderBreakdown(breakdown) {
  currentBreakdown = breakdown || [];
  breakdownEl.innerHTML = '';
  if (!currentBreakdown.length) {
    breakdownEl.hidden = true;
    return;
  }
  breakdownEl.hidden = false;
  const title = document.createElement('h2');
  title.textContent = 'School Fee Breakdown';
  breakdownEl.appendChild(title);
  const breakdownTerm = termText(currentBreakdown[0]);
  if (breakdownTerm) {
    const term = document.createElement('p');
    term.className = 'muted';
    term.textContent = `Fee period: ${breakdownTerm}`;
    breakdownEl.appendChild(term);
  }
  const note = document.createElement('p');
  note.className = 'muted';
  note.textContent = 'This shows how the school fee total is made up. If Accounts enabled part payment, you can enter the amount to pay now.';
  breakdownEl.appendChild(note);
  let total = 0;
  currentBreakdown.forEach((fee) => {
    const amount = toAmount(fee.Amount);
    total += amount;
    const row = document.createElement('div');
    row.className = 'breakdown-row';
    const name = document.createElement('span');
    const itemTerm = termText(fee);
    name.textContent = `${fee.FeeName || fee.FeeCode}${itemTerm ? ` - ${itemTerm}` : ''}`;
    const value = document.createElement('strong');
    const paid = toAmount(fee.PaidAmount);
    const original = toAmount(fee.OriginalAmount);
    const acceptanceCredit = toAmount(fee.AcceptanceCreditApplied);
    if (paid > 0 && original > 0) {
      const paidLabel = acceptanceCredit > 0
        ? `paid/credited ${formatMoney(paid, fee.Currency)} of ${formatMoney(original, fee.Currency)}`
        : `paid ${formatMoney(paid, fee.Currency)} of ${formatMoney(original, fee.Currency)}`;
      value.textContent = `${formatMoney(amount, fee.Currency)} balance (${paidLabel})`;
    } else {
      value.textContent = formatMoney(amount, fee.Currency);
    }
    row.append(name, value);
    breakdownEl.appendChild(row);
  });
  const totalRow = document.createElement('div');
  totalRow.className = 'breakdown-row total';
  const totalLabel = document.createElement('span');
  totalLabel.textContent = 'Outstanding Balance';
  const totalValue = document.createElement('strong');
  totalValue.textContent = formatMoney(total, currentBreakdown[0].Currency || 'NGN');
  totalRow.append(totalLabel, totalValue);
  breakdownEl.appendChild(totalRow);
}

function schoolFeeTotalItem(breakdown) {
  const items = (breakdown || []).filter(isSchoolFee);
  if (!items.length) return null;
  const total = items.reduce((sum, fee) => {
    return sum + toAmount(fee.Amount);
  }, 0);
  if (total <= 0) return null;
  const installmentItems = items.filter((fee) => isYes(fee.AllowInstallment));
  const installmentMinimum = items.reduce((sum, fee) => {
    if (!isYes(fee.AllowInstallment)) return sum;
    const min = toAmount(fee.MinAmount);
    return sum + (min > 0 ? min : 0);
  }, 0);
  const minimumInstallmentPortion = installmentItems.length && installmentMinimum <= 0 ? 1 : installmentMinimum;
  const minAmount = Math.min(total, minimumInstallmentPortion);
  const allowInstallment = installmentItems.length > 0 && minAmount < total;
  const originalTotal = items.reduce((sum, fee) => sum + toAmount(fee.OriginalAmount || fee.Amount), 0);
  const acceptanceCreditApplied = items.reduce((sum, fee) => sum + toAmount(fee.AcceptanceCreditApplied), 0);
  const schoolFeesTotalCreditApplied = items.reduce((sum, fee) => sum + toAmount(fee.SchoolFeesTotalCreditApplied), 0);
  const generalFeeCreditApplied = items.reduce((sum, fee) => sum + toAmount(fee.GeneralFeeCreditApplied), 0);
  const creditApplied = Math.max(0, originalTotal - total);
  return {
    FeeCode: SCHOOL_FEES_TOTAL_CODE,
    FeeName: 'School Fees Total',
    FeeCategory: 'School Fee',
    Amount: total,
    OriginalAmount: originalTotal || total,
    CreditApplied: creditApplied,
    AcceptanceCreditApplied: acceptanceCreditApplied,
    SchoolFeesTotalCreditApplied: schoolFeesTotalCreditApplied,
    GeneralFeeCreditApplied: generalFeeCreditApplied,
    PreviousFeePaymentApplied: Math.max(0, creditApplied - acceptanceCreditApplied - schoolFeesTotalCreditApplied - generalFeeCreditApplied),
    Currency: items[0].Currency || 'NGN',
    AllowInstallment: allowInstallment ? 'YES' : 'NO',
    MinAmount: allowInstallment ? minAmount : '',
    MaxAmount: total,
    PaymentType: 'SchoolFeesTotal',
    AcademicSession: items[0].AcademicSession || '',
    Term: items[0].Term || '',
    Components: items.map((fee) => ({
      FeeCode: fee.FeeCode,
      FeeName: fee.FeeName,
      FeeCategory: fee.FeeCategory || 'School Fee',
      Amount: fee.Amount,
      OriginalAmount: fee.OriginalAmount || fee.Amount,
      PaidAmount: fee.PaidAmount || '',
      AcceptanceCreditApplied: fee.AcceptanceCreditApplied || '',
      SchoolFeesTotalCreditApplied: fee.SchoolFeesTotalCreditApplied || '',
      GeneralFeeCreditApplied: fee.GeneralFeeCreditApplied || '',
      BalanceAmount: fee.BalanceAmount || fee.Amount,
      Currency: fee.Currency || items[0].Currency || 'NGN',
      AcademicSession: fee.AcademicSession || '',
      Term: fee.Term || '',
      AllowInstallment: fee.AllowInstallment || '',
      MinAmount: fee.MinAmount || '',
      MaxAmount: fee.MaxAmount || ''
    }))
  };
}

function buildPayableItems(fees, breakdown) {
  const items = [];
  const schoolTotal = schoolFeeTotalItem(breakdown);
  if (schoolTotal) {
    items.push(schoolTotal);
  }
  (fees || []).forEach((fee) => {
    if (isSchoolFee(fee)) return;
    items.push(fee);
  });
  return items;
}

function renderFees(account, fees, breakdown) {
  currentBranchId = String(account?.BranchId || 'main').trim().toLowerCase() || 'main';
  paymentIdempotencyKey = '';
  currentFees = buildPayableItems(fees || [], breakdown || []);
  feeList.innerHTML = '';
  feePanel.hidden = false;
  const accountPeriod = termText(account);
  const debugText = debugMode && account.BillingSource ? ` | Billing Source: ${account.BillingSource}` : '';
  accountSummary.textContent = `${account.DisplayName || 'Student'} | ${account.ApplicationReference || account.AccountRef || ''} | ${account.ClassName || ''} | ${account.StudentType || ''}${accountPeriod ? ' | ' + accountPeriod : ''}${debugText}`;
  renderBreakdown(breakdown || []);

  if (!currentFees.length) {
    const empty = document.createElement('p');
    empty.className = 'muted';
    empty.textContent = 'There are no payment items due at the moment.';
    feeList.appendChild(empty);
    payBtn.disabled = true;
    updateWalletAmountVisibility();
    return;
  }

  payBtn.disabled = false;
  currentFees.forEach((fee, index) => {
    const id = `fee-${index}`;
    const row = document.createElement('label');
    row.className = 'fee-option';
    const input = document.createElement('input');
    input.type = 'radio';
    input.name = 'feeCode';
    input.value = fee.FeeCode;
    input.id = id;
    input.checked = index === 0;
    input.addEventListener('change', () => {
      paymentIdempotencyKey = '';
      updateWalletAmountVisibility();
    });
    const textWrap = document.createElement('span');
    const name = document.createElement('strong');
    const feePeriod = termText(fee);
    name.textContent = `${fee.FeeName || fee.FeeCode}${fee.FeeCategory ? ` (${fee.FeeCategory})` : ''}${feePeriod ? ` - ${feePeriod}` : ''}`;
    const amount = document.createElement('small');
    if (isWalletFee(fee)) {
      amount.textContent = 'Enter amount';
    } else if (isSchoolFeesTotal(fee) && isYes(fee.AllowInstallment)) {
      amount.textContent = `${formatMoney(fee.Amount, fee.Currency)} total | part payment allowed`;
    } else {
      amount.textContent = formatMoney(fee.Amount, fee.Currency);
    }
    textWrap.append(name, amount);
    row.append(input, textWrap);
    feeList.appendChild(row);
  });
  updateWalletAmountVisibility();
}

otpRequestForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  currentAdmissionNumber = document.getElementById('admissionNumber').value.trim().toUpperCase();
  clearGuestPaymentAuthorization();
  lookupForm.hidden = true;
  if (!currentAdmissionNumber) {
    setStatus('Enter the student admission number.', 'bad');
    return;
  }
  if (!window.DynamaxActionFeedback.begin(sendOtpBtn, 'Sending OTP...')) return;
  setStatus('Verifying the admission number and contacting the parent...', '');

  try {
    const turnstile = await publicTurnstile('guest_fee_otp_request');
    const response = await fetch('/api/guest-fee-payment', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'requestOtp',
        admissionNumber: currentAdmissionNumber,
        ...turnstile
      })
    });
    const data = await response.json().catch(() => null);
    if (!response.ok || !data?.ok) throw new Error(data?.message || 'The OTP could not be sent.');
    guestPaymentChallengeId = String(data.challengeId || '');
    otpDeliverySummary.textContent = `OTP sent to ${data.maskedParentEmail}. Ask the parent to forward the code only if they approve this payment. It expires in ${data.expiresInMinutes || 10} minutes.`;
    otpRequestForm.hidden = true;
    lookupForm.hidden = false;
    document.getElementById('otp').value = '';
    document.getElementById('otp').focus({ preventScroll: false });
    setStatus(data.message || 'OTP sent to the parent.', 'ok');
  } catch (error) {
    setStatus(error.message, 'bad');
  } finally {
    window.DynamaxActionFeedback.end(sendOtpBtn);
  }
});

lookupForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const otp = document.getElementById('otp').value.trim();
  feePanel.hidden = true;
  if (!guestPaymentToken && (!guestPaymentChallengeId || !/^\d{6}$/.test(otp))) {
    setStatus('Enter the six-digit OTP sent to the parent.', 'bad');
    return;
  }
  if (!window.DynamaxActionFeedback.begin(lookupBtn, 'Checking fees...')) return;
  setStatus('Confirming parent approval...', '');

  try {
    if (!guestPaymentToken) {
      const verificationTurnstile = await publicTurnstile('guest_fee_otp_verify');
      const verificationResponse = await fetch('/api/guest-fee-payment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'verifyOtp',
          challengeId: guestPaymentChallengeId,
          otp,
          ...verificationTurnstile
        })
      });
      const verification = await verificationResponse.json().catch(() => null);
      if (!verificationResponse.ok || !verification?.ok) {
        throw new Error(verification?.message || 'The OTP could not be verified.');
      }
      guestPaymentToken = String(verification.guestPaymentToken || '');
      guestPaymentChallengeId = '';
      if (!guestPaymentToken) throw new Error('Payment authorization was not issued. Request a new OTP.');
    }
    const turnstile = await publicTurnstile('payment_lookup');
    const response = await fetch('/api/payment-options', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ guestPaymentToken, ...turnstile })
    });
    const data = await response.json();
    if (!response.ok || !data?.ok) {
      throw new Error(data.message || 'Could not load payable fees.');
    }
    renderFees(data.account || {}, data.fees || [], data.schoolFeeBreakdown || []);
    lookupForm.hidden = true;
    setStatus(`Parent approval confirmed for ${currentAdmissionNumber}. Review the payable amount, then choose a payment method.`, 'ok');
  } catch (error) {
    if (/expired|invalid|no longer valid|too many/i.test(error.message)) {
      guestPaymentChallengeId = '';
      guestPaymentToken = '';
      otpRequestForm.hidden = false;
    }
    setStatus(error.message, 'bad');
  } finally {
    window.DynamaxActionFeedback.end(lookupBtn);
  }
});

restartOtpBtn?.addEventListener('click', () => {
  clearGuestPaymentAuthorization();
  otpRequestForm.hidden = false;
  lookupForm.hidden = true;
  document.getElementById('otp').value = '';
  document.getElementById('admissionNumber').focus({ preventScroll: false });
  setStatus('Enter another admission number to request a new parent OTP.', '');
});

payBtn.addEventListener('click', async () => {
  const fee = selectedFee();
  if (!fee) {
    setStatus('Select a payment item to pay.', 'bad');
    return;
  }
  const rules = paymentAmountRules(fee);
  const enteredAmount = rules.show ? toAmount(walletAmountInput.value) : 0;
  if (rules.show && (!Number.isFinite(enteredAmount) || enteredAmount <= 0)) {
    setStatus('Enter the amount to pay.', 'bad');
    return;
  }
  if (rules.show && rules.min > 0 && enteredAmount < rules.min) {
    setStatus(`Minimum amount is ${formatMoney(rules.min, fee.Currency)}.`, 'bad');
    return;
  }
  if (rules.show && rules.max > 0 && enteredAmount > rules.max) {
    setStatus(`Maximum amount is ${formatMoney(rules.max, fee.Currency)}.`, 'bad');
    return;
  }

  try {
    const amount = rules.show ? enteredAmount : toAmount(fee.Amount);
    const paymentChoice = await window.DynamaxPaymentMethods.choose({ branchId: currentBranchId, currency: fee.Currency || 'NGN', amount });
    if (!paymentChoice) return;
    if (!window.DynamaxActionFeedback.begin(payBtn, paymentChoice.paymentMethod === 'direct_bank_transfer' ? 'Submitting transfer...' : 'Starting checkout...')) return;
    setStatus(paymentChoice.paymentMethod === 'direct_bank_transfer' ? 'Submitting your transfer for verification...' : 'Starting secure checkout...', '');
    paymentIdempotencyKey = paymentIdempotencyKey || newIdempotencyKey();
    const turnstile = await publicTurnstile('init_payment');
    const response = await fetch('/api/init-payment', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Idempotency-Key': paymentIdempotencyKey
      },
      body: JSON.stringify({
        guestPaymentToken,
        feeCode: fee.FeeCode,
        components: fee.Components || undefined,
        amount: rules.show ? enteredAmount : undefined,
        ...paymentChoice,
        idempotencyKey: paymentIdempotencyKey,
        ...turnstile
      })
    });
    const data = await response.json().catch(() => null);
    if (!response.ok || !data?.ok) {
      if (shouldReleaseIdempotencyKey(response, data)) paymentIdempotencyKey = '';
      throw new Error(data?.message || 'Could not initialize payment.');
    }
    paymentIdempotencyKey = '';
    if (data.directTransfer) {
      setStatus(window.DynamaxPaymentMethods.directTransferMessage(data), 'ok');
      window.DynamaxActionFeedback.end(payBtn);
      return;
    }
    window.location.href = data.authorizationUrl;
  } catch (error) {
    if (/expired|invalid|no longer valid/i.test(error.message)) {
      clearGuestPaymentAuthorization();
      otpRequestForm.hidden = false;
      lookupForm.hidden = true;
    }
    setStatus(error.message, 'bad');
    window.DynamaxActionFeedback.end(payBtn);
  }
});

walletAmountInput?.addEventListener('input', () => {
  if (!payBtn.disabled) paymentIdempotencyKey = '';
});
